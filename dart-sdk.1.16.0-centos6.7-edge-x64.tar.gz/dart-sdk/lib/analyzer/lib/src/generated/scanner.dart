// Copyright (c) 2014, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

@deprecated
library analyzer.src.generated.scanner;

export 'package:analyzer/dart/ast/token.dart';
export 'package:analyzer/src/dart/ast/token.dart' hide SimpleToken;
export 'package:analyzer/src/dart/scanner/scanner.dart';
export 'package:analyzer/src/dart/scanner/reader.dart';
